# sweet_functor
A collection of functor including comparator, validator.

WIP ...